function Footer(){
    return (
        <h5>Zapraszamy codziennie od 9:30 do 17:00</h5>
    )
}

export default Footer;